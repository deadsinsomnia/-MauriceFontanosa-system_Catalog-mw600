# The Research Archive — Department of Psychology

A static front-end for a departmental thesis archive: psychology students and
faculty browse past student and faculty research, read the abstract, and see
whether a physical copy is available to borrow. No build step, no backend —
plain HTML, CSS, and JavaScript, with a `ThesisRepository` module that
handles all data access.

## Pages

| Page          | File                | Purpose                                          |
|---------------|---------------------|---------------------------------------------------|
| Archive index | `index.html`        | Browse all records; search, filter, delete        |
| Record detail | `thesis.html`       | Read the full abstract and metadata; edit/delete  |
| Add a record  | `add-thesis.html`   | Catalog a new thesis                              |
| Edit a record | `edit-thesis.html`  | Update an existing record                         |

## Fields

Each record has: **title, author, research area, year completed, call
number, abstract, and borrowing status** (`available`, `checked-out`, or
`reserved`).

> Note on scope: the original brief specified *title, author, category,
> ISBN, availability*. For a thesis archive, "category" and "ISBN" don't
> quite fit — theses aren't issued ISBNs, and the browsing/borrowing
> experience the brief describes depends on reading an abstract. So this
> build renames *category → research area*, replaces *ISBN → call number*
> (the archive's internal accession code), and adds *abstract* and *year
> completed* as first-class fields.

## Running it

This is a fully static site — no server, build step, or install required.
Just double-click `index.html` (or any of the other pages) and it opens
straight in your browser. There's no `fetch`, no ES module imports, and no
external dependency besides two Google Fonts stylesheets, so every script
loads via a plain `<script src>` tag and `localStorage` works the same way
it would if the files were served over `http://`.

If you'd still prefer to serve it (e.g. for cleaner root-relative links
while developing), that works too:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## How data is stored

`js/repository.js` implements a repository pattern around `localStorage`:
`ThesisRepository.getAll()`, `getById()`, `add()`, `update()`, `remove()`,
`getResearchAreas()`, and `resetToSeed()`. Every page calls into this module
instead of touching storage directly, so the storage engine (currently
`localStorage`) can be swapped for a real API later by editing this one file.

The archive seeds itself with 8 sample thesis records the first time it
loads. Use the **"Reset to sample data"** link in the footer of the archive
page to restore that seed set at any point.

## Project structure

```
library-catalog/
├── index.html           # Archive index (list) page
├── thesis.html            # Record detail page
├── add-thesis.html         # Add-record form
├── edit-thesis.html         # Edit-record form
├── css/
│   └── style.css          # Design system + all page styles
├── js/
│   ├── repository.js       # Data layer (CRUD over localStorage)
│   ├── ui.js                 # Toasts, confirm dialog, label/color helpers
│   ├── validation.js          # Shared form validation
│   ├── catalog.js               # index.html logic
│   ├── detail.js                  # thesis.html logic
│   ├── add.js                       # add-thesis.html logic
│   └── edit.js                        # edit-thesis.html logic
└── server/                # Express + MySQL backend — see server/README.md
    ├── server.js
    ├── db.js
    ├── routes/theses.js
    └── sql/                # schema.sql + seed.sql, for XAMPP's MySQL
```

## Backend (Express + XAMPP MySQL)

`server/` is a complete Express REST API (list/search/filter, create,
update, delete) that talks to MySQL via `mysql2`, meant to run against
XAMPP's bundled MySQL server. **See `server/README.md`** for setup steps
and the full API reference.

It is not wired into the frontend yet — `index.html` and friends still
read/write `localStorage` through `js/repository.js`, exactly as before.
Connecting the two (swapping `repository.js` to call the API instead of
`localStorage`) is a separate, deliberate next step.

## Design

**Concept.** An academic reading room rendered for the browser — closer to a
journal masthead and an abstract offprint than a generic admin dashboard.
The listing page reads like a bibliography index; the detail page reads like
a paper's title/abstract page.

**Color.**

| Token         | Hex       | Used for                                     |
|---------------|-----------|-----------------------------------------------|
| Deep forest   | `#1f3d2e` | Masthead, primary buttons, headings           |
| Sage green    | `#4f6b52` | Secondary accents, one of the area-rule colors |
| Warm ivory    | `#faf6ec` | Page background                                |
| Soft beige    | `#eee4d0` | Reserved for subtle surface fills              |
| Muted gold    | `#ad8a4e` | The one accent color — CTAs, the abstract label, status dot |
| Charcoal      | `#26241f` | Body text                                      |
| Cool gray     | `#8d95a1` | Secondary text, borders, dividers              |

**Type.** *Newsreader* (an optical-size serif built for long-form reading)
carries titles, bylines, and the abstract text itself, in italic for
bylines to echo citation convention. *Inter* handles UI chrome — labels,
buttons, form fields. *IBM Plex Mono* is reserved for call numbers, the
one place a typewritten, catalog-code feel is actually appropriate.

**Layout.** Each archive entry keeps a thin color-coded rule on its left
edge — one color per research area, functioning like a journal's
section-color system rather than decoration. The detail page separates the
abstract (serif, generous line-height, capped at a readable measure) from
the metadata table beneath it, so the abstract — the thing a student
actually came to read — gets visual priority.

## Accessibility fixes

An audit against WCAG contrast requirements and standard dialog/form
patterns turned up a few real issues, since fixed:

- **Color contrast.** The "Reserved" status text (was `#ad8a4e` on cream,
  3.17:1) and all secondary/muted text using cool-gray (was `#8d95a1`,
  2.8–2.97:1) failed WCAG AA's 4.5:1 minimum for normal text. Both are now
  darkened (`#8a6c35` and `#636b78` respectively) to land at 4.8–5.3:1.
- **Radio group semantics.** The "Borrowing status" radio group used a
  plain `<label>` next to the inputs, so a screen reader wouldn't announce
  the group's name when focus entered it. It's now a proper
  `<fieldset>`/`<legend>`.
- **Focus trap.** The delete-confirmation dialog closed on Escape but
  didn't stop Tab from cycling focus out to the page behind it. It now
  traps Tab/Shift+Tab within the dialog and returns focus to the
  triggering element on close, per the WAI-ARIA dialog pattern.
- **Touch targets.** Row-level Edit/Delete buttons were roughly 28–32px
  tall with tight spacing — under the 44px guideline WCAG 2.5.5 and the
  major mobile platforms recommend. They're now taller with more spacing
  between them, especially at mobile widths where taps (not clicks) are
  the primary input.
- **Toast announcements.** Confirmation toasts ("Record added…", "Record
  deleted…") now live in an `aria-live="polite"` region so screen readers
  announce them, not just sighted users.
