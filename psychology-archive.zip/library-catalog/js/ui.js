/**
 * Shared UI helpers: toast notifications, the delete-confirmation dialog,
 * and the research-area/status → color mapping used to tint the archive's
 * index rules.
 */

const STATUS_LABELS = {
  available: "Available to borrow",
  "checked-out": "Currently on loan",
  reserved: "Reserved",
};

const AREA_RULE_COLORS = [
  "rule-forest",
  "rule-sage",
  "rule-gold",
  "rule-charcoal",
  "rule-rust",
  "rule-plum",
];

/** Deterministic color class for a research area, so the same area is
 *  always the same rule color across pages and sessions. */
function areaRuleClass(area) {
  let hash = 0;
  for (let i = 0; i < area.length; i++) {
    hash = (hash * 31 + area.charCodeAt(i)) >>> 0;
  }
  return AREA_RULE_COLORS[hash % AREA_RULE_COLORS.length];
}

function statusLabel(status) {
  return STATUS_LABELS[status] || status;
}

/** Brief toast in the corner, e.g. "Record added to the archive." */
function showToast(message) {
  let host = document.getElementById("toast-host");
  if (!host) {
    host = document.createElement("div");
    host.id = "toast-host";
    host.className = "toast-host";
    host.setAttribute("role", "status");
    host.setAttribute("aria-live", "polite");
    document.body.appendChild(host);
  }
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  host.appendChild(toast);
  requestAnimationFrame(() => toast.classList.add("toast-visible"));
  setTimeout(() => {
    toast.classList.remove("toast-visible");
    setTimeout(() => toast.remove(), 250);
  }, 2600);
}

/** Promise-based confirm dialog styled to match the archive look.
 *  Resolves true if the person confirms, false otherwise. Traps focus
 *  within the dialog while it's open, per the WAI-ARIA dialog pattern. */
function confirmDialog({ title, message, confirmText = "Delete", danger = true }) {
  return new Promise((resolve) => {
    const previouslyFocused = document.activeElement;
    const overlay = document.createElement("div");
    overlay.className = "dialog-overlay";
    overlay.innerHTML = `
      <div class="dialog-card" role="alertdialog" aria-modal="true" aria-labelledby="dialog-title">
        <h2 id="dialog-title">${title}</h2>
        <p>${message}</p>
        <div class="dialog-actions">
          <button type="button" class="btn btn-ghost" data-action="cancel">Cancel</button>
          <button type="button" class="btn ${danger ? "btn-danger" : "btn-primary"}" data-action="confirm">${confirmText}</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
    const cardEl = overlay.querySelector(".dialog-card");
    const focusableSelector = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
    requestAnimationFrame(() => overlay.classList.add("dialog-visible"));

    function close(result) {
      overlay.classList.remove("dialog-visible");
      setTimeout(() => overlay.remove(), 200);
      document.removeEventListener("keydown", onKey);
      if (previouslyFocused && typeof previouslyFocused.focus === "function") {
        previouslyFocused.focus();
      }
      resolve(result);
    }

    function onKey(e) {
      if (e.key === "Escape") {
        close(false);
        return;
      }
      if (e.key !== "Tab") return;
      // Trap focus inside the dialog: wrap Tab/Shift+Tab at its edges
      // instead of letting focus escape to the page behind it.
      const focusable = Array.from(cardEl.querySelectorAll(focusableSelector));
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }

    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) close(false);
    });
    overlay.querySelector('[data-action="cancel"]').addEventListener("click", () => close(false));
    overlay.querySelector('[data-action="confirm"]').addEventListener("click", () => close(true));
    document.addEventListener("keydown", onKey);
    cardEl.querySelector(".btn-danger, .btn-primary").focus();
  });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

/** Trim an abstract down to a one-line teaser for list views. */
function abstractTeaser(text, maxLen = 148) {
  const clean = text.replace(/\s+/g, " ").trim();
  if (clean.length <= maxLen) return clean;
  return clean.slice(0, maxLen).replace(/\s+\S*$/, "") + "…";
}
