/**
 * ThesisRepository
 * ------------------
 * A small repository layer that isolates every read/write against the
 * data store (localStorage, in this static build) from the page code.
 * Pages never touch localStorage directly — they call these methods.
 * Swap the storage engine later (a real API, IndexedDB, etc.) by
 * rewriting this one file; nothing else has to change.
 */
const ThesisRepository = (() => {
  const STORAGE_KEY = "psych_archive_records_v2";

  const SEED_RECORDS = [
    {
      title: "Attachment Styles and Emotion Regulation in Adult Romantic Relationships",
      author: "Priya Anand",
      researchArea: "Clinical Psychology",
      year: "2023",
      callNumber: "PSY-2023-014",
      abstract:
        "This study examines how adult attachment orientation predicts the emotion-regulation strategies partners use during conflict. Ninety-four cohabiting couples completed the Experiences in Close Relationships scale and a structured conflict-recall task. Anxious attachment was associated with greater reliance on suppression, while avoidant attachment predicted lower engagement during repair attempts. Findings are discussed in relation to emotionally focused therapy.",
      availability: "available",
    },
    {
      title: "Working Memory Load and Susceptibility to Misinformation",
      author: "Dr. Corwin Alde",
      researchArea: "Cognitive Psychology",
      year: "2021",
      callNumber: "PSY-2021-002",
      abstract:
        "Across three experiments, participants viewed simulated news events followed by misleading post-event information under varying working-memory load. Higher concurrent load increased susceptibility to the misinformation effect on later recognition tests, but only when the misleading detail was central to the narrative. Results support a resource-limited account of source monitoring.",
      availability: "checked-out",
    },
    {
      title: "Peer Victimization and Self-Concept Development in Early Adolescence",
      author: "Renata Okafor",
      researchArea: "Developmental Psychology",
      year: "2022",
      callNumber: "PSY-2022-031",
      abstract:
        "This longitudinal study followed 210 students from grades 6 through 8 to assess how relational and overt peer victimization shape global and domain-specific self-concept. Relational victimization showed the strongest negative association with social self-concept, and this relationship was partially buffered by close friendship quality. Implications for school-based intervention are discussed.",
      availability: "available",
    },
    {
      title: "In-Group Favoritism Under Minimal Group Conditions: A Replication",
      author: "Hugh Tarrant",
      researchArea: "Social Psychology",
      year: "2020",
      callNumber: "PSY-2020-047",
      abstract:
        "A pre-registered replication of the classic minimal group paradigm was conducted with a university sample (N = 168) to test whether arbitrary group assignment alone is sufficient to produce resource-allocation bias. In-group favoritism was observed at a smaller effect size than the original studies, and its magnitude was moderated by participants' self-reported need for group belonging.",
      availability: "available",
    },
    {
      title: "Remote Work Autonomy and Burnout Among Early-Career Professionals",
      author: "Lian Osei",
      researchArea: "Industrial-Organizational Psychology",
      year: "2023",
      callNumber: "PSY-2023-019",
      abstract:
        "Using a mixed-methods design, this thesis investigates how perceived autonomy in remote work arrangements relates to emotional exhaustion among employees in their first five years of a career. Survey data from 187 respondents indicated that autonomy buffered burnout only when paired with clearly communicated performance expectations, a pattern corroborated in follow-up interviews.",
      availability: "reserved",
    },
    {
      title: "Therapeutic Alliance as a Predictor of Outcome in Brief CBT for Anxiety",
      author: "Delphine Cruz",
      researchArea: "Counseling Psychology",
      year: "2019",
      callNumber: "PSY-2019-008",
      abstract:
        "This thesis analyzes session-by-session alliance ratings from 58 clients receiving an eight-session CBT protocol for generalized anxiety. Early alliance strength, rather than alliance growth over time, was the stronger predictor of symptom reduction at termination, suggesting that establishing rapport in the first sessions may be disproportionately important in brief treatment formats.",
      availability: "available",
    },
    {
      title: "Sleep Fragmentation and Prospective Memory in Undergraduate Students",
      author: "Yusuf Bramwell",
      researchArea: "Cognitive Psychology",
      year: "2022",
      callNumber: "PSY-2022-011",
      abstract:
        "Actigraphy and self-report sleep logs were collected from 76 undergraduates over two weeks alongside a time-based prospective memory task. Greater night-to-night sleep fragmentation, independent of total sleep time, predicted more missed prospective-memory cues, pointing to sleep continuity rather than duration as the more relevant factor for this cognitive domain.",
      availability: "available",
    },
    {
      title: "Neural Correlates of Cognitive Reappraisal in Adolescents with Anxiety",
      author: "Dr. Marisol Feyn",
      researchArea: "Neuropsychology",
      year: "2021",
      callNumber: "PSY-2021-025",
      abstract:
        "Using fMRI during an emotion-regulation task, this study compares prefrontal-amygdala connectivity during cognitive reappraisal in adolescents with an anxiety disorder diagnosis and matched controls. The anxiety group showed reduced ventrolateral prefrontal engagement and weaker top-down connectivity, a pattern that correlated with self-reported reappraisal difficulty in daily life.",
      availability: "checked-out",
    },
  ];

  function generateId() {
    return "th_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  function readRaw() {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  }

  function writeRaw(records) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
  }

  function seedIfEmpty() {
    if (readRaw() === null) {
      const seeded = SEED_RECORDS.map((r) => ({
        id: generateId(),
        ...r,
        dateAdded: new Date().toISOString(),
      }));
      writeRaw(seeded);
    }
  }

  /** Return every thesis record. */
  function getAll() {
    seedIfEmpty();
    return readRaw() || [];
  }

  /** Return a single record by id, or null if it doesn't exist. */
  function getById(id) {
    return getAll().find((r) => r.id === id) || null;
  }

  /** Insert a new record. Returns the stored record (with its new id). */
  function add(fields) {
    const records = getAll();
    const record = {
      id: generateId(),
      title: fields.title.trim(),
      author: fields.author.trim(),
      researchArea: fields.researchArea.trim(),
      year: fields.year.trim(),
      callNumber: fields.callNumber.trim(),
      abstract: fields.abstract.trim(),
      availability: fields.availability,
      dateAdded: new Date().toISOString(),
    };
    records.push(record);
    writeRaw(records);
    return record;
  }

  /** Patch an existing record by id. Returns the updated record, or null. */
  function update(id, fields) {
    const records = getAll();
    const idx = records.findIndex((r) => r.id === id);
    if (idx === -1) return null;
    records[idx] = {
      ...records[idx],
      title: fields.title.trim(),
      author: fields.author.trim(),
      researchArea: fields.researchArea.trim(),
      year: fields.year.trim(),
      callNumber: fields.callNumber.trim(),
      abstract: fields.abstract.trim(),
      availability: fields.availability,
    };
    writeRaw(records);
    return records[idx];
  }

  /** Remove a record by id. */
  function remove(id) {
    const records = getAll().filter((r) => r.id !== id);
    writeRaw(records);
  }

  /** Distinct research-area list, for filters and datalists. */
  function getResearchAreas() {
    return [...new Set(getAll().map((r) => r.researchArea))].sort();
  }

  /** Wipe everything back to the seed set (used by the "reset data" control). */
  function resetToSeed() {
    localStorage.removeItem(STORAGE_KEY);
    seedIfEmpty();
  }

  return { getAll, getById, add, update, remove, getResearchAreas, resetToSeed };
})();
