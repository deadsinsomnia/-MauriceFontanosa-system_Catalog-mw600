(function () {
  const form = document.getElementById("add-form");
  const areaOptions = document.getElementById("area-options");

  areaOptions.innerHTML = ThesisRepository.getResearchAreas()
    .map((a) => `<option value="${escapeHtml(a)}"></option>`)
    .join("");

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const { valid, values } = validateBookForm(form);
    if (!valid) return;
    const record = ThesisRepository.add(values);
    window.location.href = `thesis.html?id=${encodeURIComponent(record.id)}&added=1`;
  });
})();
