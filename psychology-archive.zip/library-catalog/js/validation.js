/**
 * Validates the shared thesis-record form. `form` is the <form> element;
 * fields are expected by id: title, author, researchArea, year,
 * callNumber, abstract, availability.
 * Returns { valid, values } — values is only populated when valid.
 */
function validateBookForm(form) {
  const title = form.title.value.trim();
  const author = form.author.value.trim();
  const researchArea = form.researchArea.value.trim();
  const year = form.year.value.trim();
  const callNumber = form.callNumber.value.trim();
  const abstract = form.abstract.value.trim();
  const availability = form.availability.value;

  let valid = true;

  const setError = (fieldId, hasError) => {
    const el = document.getElementById(fieldId);
    el.classList.toggle("has-error", hasError);
    if (hasError) valid = false;
  };

  setError("field-title", title.length === 0);
  setError("field-author", author.length === 0);
  setError("field-researchArea", researchArea.length === 0);

  const currentYear = new Date().getFullYear();
  const yearValid = /^\d{4}$/.test(year) && Number(year) >= 1950 && Number(year) <= currentYear + 1;
  setError("field-year", !yearValid);

  setError("field-callNumber", callNumber.length === 0);
  setError("field-abstract", abstract.length < 20);

  return {
    valid,
    values: valid ? { title, author, researchArea, year, callNumber, abstract, availability } : null,
  };
}
