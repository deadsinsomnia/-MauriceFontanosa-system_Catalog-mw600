(function () {
  const region = document.getElementById("detail-region");
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");
  const record = id ? ThesisRepository.getById(id) : null;

  function dateAddedLabel(iso) {
    try {
      return new Date(iso).toLocaleDateString(undefined, {
        year: "numeric",
        month: "long",
        day: "numeric",
      });
    } catch {
      return iso;
    }
  }

  if (!record) {
    region.innerHTML = `
      <div class="empty-state">
        <h3>Record not found</h3>
        <p>This entry may have been deleted, or the link is out of date.</p>
        <a href="index.html" class="btn btn-brass">Back to the archive</a>
      </div>`;
    return;
  }

  document.title = `${record.title} — Department of Psychology`;

  region.innerHTML = `
    <div class="card-detail">
      <div class="card-detail__call">${escapeHtml(record.callNumber)}</div>
      <h2>${escapeHtml(record.title)}</h2>
      <p class="byline"><strong>${escapeHtml(record.author)}</strong> — ${escapeHtml(record.researchArea)}, ${escapeHtml(record.year)}</p>

      <div class="card-detail__abstract-label">Abstract</div>
      <p class="card-detail__abstract">${escapeHtml(record.abstract)}</p>

      <dl>
        <dt>Research area</dt>
        <dd>${escapeHtml(record.researchArea)}</dd>
        <dt>Call number</dt>
        <dd class="accession">${escapeHtml(record.callNumber)}</dd>
        <dt>Borrowing status</dt>
        <dd><span class="status-pill status-${record.availability}">${statusLabel(record.availability)}</span></dd>
        <dt>Archived on</dt>
        <dd>${dateAddedLabel(record.dateAdded)}</dd>
      </dl>

      <div class="card-detail__actions">
        <a class="btn btn-primary" href="edit-thesis.html?id=${encodeURIComponent(record.id)}">Edit record</a>
        <button type="button" class="btn btn-danger" id="delete-btn">Delete record</button>
        <a class="btn btn-ghost" href="index.html">Back to archive</a>
      </div>
    </div>
  `;

  if (params.get("added") === "1") {
    showToast("Record added to the archive.");
  } else if (params.get("updated") === "1") {
    showToast("Record updated.");
  }

  document.getElementById("delete-btn").addEventListener("click", async () => {
    const ok = await confirmDialog({
      title: "Delete this record?",
      message: `“${record.title}” by ${record.author} will be removed from the archive. This can't be undone.`,
      confirmText: "Delete record",
    });
    if (ok) {
      ThesisRepository.remove(record.id);
      window.location.href = "index.html";
    }
  });
})();
