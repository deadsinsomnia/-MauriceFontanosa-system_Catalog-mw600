(function () {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");
  const record = id ? ThesisRepository.getById(id) : null;
  const formRegion = document.getElementById("form-region");

  if (!record) {
    formRegion.innerHTML = `
      <div class="empty-state">
        <h3>Record not found</h3>
        <p>This entry may have been deleted, or the link is out of date.</p>
        <a href="index.html" class="btn btn-brass">Back to the archive</a>
      </div>`;
    return;
  }

  document.title = `Edit ${record.title} — Department of Psychology`;

  const form = document.getElementById("edit-form");
  const areaOptions = document.getElementById("area-options");
  areaOptions.innerHTML = ThesisRepository.getResearchAreas()
    .map((a) => `<option value="${escapeHtml(a)}"></option>`)
    .join("");

  form.title.value = record.title;
  form.author.value = record.author;
  form.researchArea.value = record.researchArea;
  form.year.value = record.year;
  form.callNumber.value = record.callNumber;
  form.abstract.value = record.abstract;
  const radio = form.querySelector(`input[name="availability"][value="${record.availability}"]`);
  if (radio) radio.checked = true;

  document.getElementById("cancel-link").href = `thesis.html?id=${encodeURIComponent(record.id)}`;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const { valid, values } = validateBookForm(form);
    if (!valid) return;
    ThesisRepository.update(record.id, values);
    window.location.href = `thesis.html?id=${encodeURIComponent(record.id)}&updated=1`;
  });
})();
