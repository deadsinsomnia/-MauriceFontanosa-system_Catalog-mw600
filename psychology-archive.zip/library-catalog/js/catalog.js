(function () {
  const listRegion = document.getElementById("list-region");
  const searchInput = document.getElementById("search-input");
  const areaFilter = document.getElementById("area-filter");
  const statusFilter = document.getElementById("status-filter");
  const resultCount = document.getElementById("result-count");
  const resetBtn = document.getElementById("reset-data");

  function populateAreaFilter() {
    const areas = ThesisRepository.getResearchAreas();
    areaFilter.innerHTML =
      '<option value="">All research areas</option>' +
      areas.map((a) => `<option value="${escapeHtml(a)}">${escapeHtml(a)}</option>`).join("");
  }

  function render() {
    const records = ThesisRepository.getAll();
    const q = searchInput.value.trim().toLowerCase();
    const area = areaFilter.value;
    const status = statusFilter.value;

    const filtered = records.filter((r) => {
      const matchesQuery =
        !q || r.title.toLowerCase().includes(q) || r.author.toLowerCase().includes(q);
      const matchesArea = !area || r.researchArea === area;
      const matchesStatus = !status || r.availability === status;
      return matchesQuery && matchesArea && matchesStatus;
    });

    resultCount.textContent = `${filtered.length} of ${records.length} record${records.length === 1 ? "" : "s"}`;

    if (records.length === 0) {
      listRegion.innerHTML = `
        <div class="empty-state">
          <h3>The archive is empty</h3>
          <p>Add the department's first thesis record to start the collection.</p>
          <a href="add-thesis.html" class="btn btn-brass">+ Add a record</a>
        </div>`;
      return;
    }

    if (filtered.length === 0) {
      listRegion.innerHTML = `
        <div class="empty-state">
          <h3>No matches</h3>
          <p>No record matches that search and filter combination. Try clearing a filter.</p>
        </div>`;
      return;
    }

    listRegion.innerHTML = `<div class="catalog-list">${filtered
      .slice()
      .sort((a, b) => a.title.localeCompare(b.title))
      .map(
        (r) => `
      <div class="catalog-row" data-id="${r.id}">
        <div class="catalog-row__tab ${areaRuleClass(r.researchArea)}"></div>
        <div class="catalog-row__call">${escapeHtml(r.callNumber)}</div>
        <div class="catalog-row__main">
          <a href="thesis.html?id=${encodeURIComponent(r.id)}">${escapeHtml(r.title)}</a>
          <div class="catalog-row__byline">${escapeHtml(r.author)} &middot; ${escapeHtml(r.researchArea)} &middot; ${escapeHtml(r.year)}</div>
          <div class="catalog-row__teaser">${escapeHtml(abstractTeaser(r.abstract))}</div>
        </div>
        <div class="status-pill status-${r.availability}">${statusLabel(r.availability)}</div>
        <div class="catalog-row__actions">
          <a class="btn btn-ghost btn-small" href="edit-thesis.html?id=${encodeURIComponent(r.id)}">Edit</a>
          <button type="button" class="btn btn-danger btn-small" data-delete="${r.id}">Delete</button>
        </div>
      </div>`
      )
      .join("")}</div>`;
  }

  listRegion.addEventListener("click", async (e) => {
    const btn = e.target.closest("[data-delete]");
    if (!btn) return;
    const id = btn.getAttribute("data-delete");
    const record = ThesisRepository.getById(id);
    if (!record) return;
    const ok = await confirmDialog({
      title: "Delete this record?",
      message: `“${record.title}” by ${record.author} will be removed from the archive. This can't be undone.`,
      confirmText: "Delete record",
    });
    if (ok) {
      ThesisRepository.remove(id);
      populateAreaFilter();
      render();
      showToast("Record deleted from the archive.");
    }
  });

  searchInput.addEventListener("input", render);
  areaFilter.addEventListener("change", render);
  statusFilter.addEventListener("change", render);

  resetBtn.addEventListener("click", async () => {
    const ok = await confirmDialog({
      title: "Reset to sample data?",
      message: "This replaces every record currently in the archive with the original sample set.",
      confirmText: "Reset data",
    });
    if (ok) {
      ThesisRepository.resetToSeed();
      populateAreaFilter();
      render();
      showToast("Archive reset to sample data.");
    }
  });

  populateAreaFilter();
  render();
})();
