require("dotenv").config();
const express = require("express");
const cors = require("cors");
const pool = require("./db");
const thesesRouter = require("./routes/theses");

const app = express();

app.use(cors()); // allows the static frontend (a different origin/port) to call this API
app.use(express.json());

// Quick check that the server is up and can reach MySQL.
app.get("/api/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ status: "ok", database: "connected" });
  } catch (err) {
    res.status(500).json({ status: "error", database: "unreachable", detail: err.message });
  }
});

app.use("/api/theses", thesesRouter);

app.use((req, res) => {
  res.status(404).json({ error: "Not found." });
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error("Unhandled error:", err);
  res.status(500).json({ error: "Something went wrong on the server." });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Psychology Archive API running at http://localhost:${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/api/health`);
});
