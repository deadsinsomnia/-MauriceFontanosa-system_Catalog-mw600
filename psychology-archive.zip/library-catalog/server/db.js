// MySQL connection pool. A pool (rather than one long-lived connection)
// lets multiple requests hit the database concurrently without waiting
// on each other, and reconnects automatically if a connection drops.
require("dotenv").config();
const mysql = require("mysql2/promise");

const pool = mysql.createPool({
  host: process.env.DB_HOST || "127.0.0.1",
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "", // XAMPP's default root user has no password
  database: process.env.DB_NAME || "psych_archive",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

module.exports = pool;
