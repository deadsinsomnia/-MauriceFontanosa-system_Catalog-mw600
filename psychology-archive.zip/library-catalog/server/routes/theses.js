const express = require("express");
const pool = require("../db");

const router = express.Router();

const REQUIRED_FIELDS = ["title", "author", "researchArea", "year", "callNumber", "abstract"];
const VALID_STATUSES = ["available", "checked-out", "reserved"];

function validateBody(body) {
  const missing = REQUIRED_FIELDS.filter((f) => !body[f] || !String(body[f]).trim());
  if (missing.length > 0) {
    return `Missing required field(s): ${missing.join(", ")}.`;
  }
  if (!/^\d{4}$/.test(body.year)) {
    return "Year must be a 4-digit number.";
  }
  if (body.availability && !VALID_STATUSES.includes(body.availability)) {
    return `Availability must be one of: ${VALID_STATUSES.join(", ")}.`;
  }
  return null;
}

// GET /api/theses?search=&area=&status=
// Returns every record, optionally filtered — mirrors the frontend's
// search box and two filter dropdowns.
router.get("/", async (req, res) => {
  try {
    const { search, area, status } = req.query;
    let sql = "SELECT * FROM theses WHERE 1 = 1";
    const params = [];

    if (search) {
      sql += " AND (title LIKE ? OR author LIKE ?)";
      params.push(`%${search}%`, `%${search}%`);
    }
    if (area) {
      sql += " AND research_area = ?";
      params.push(area);
    }
    if (status) {
      sql += " AND availability = ?";
      params.push(status);
    }
    sql += " ORDER BY title ASC";

    const [rows] = await pool.query(sql, params);
    res.json(rows.map(toApiRecord));
  } catch (err) {
    console.error("GET /api/theses failed:", err);
    res.status(500).json({ error: "Failed to fetch records." });
  }
});

// GET /api/theses/research-areas — distinct list, for the add/edit form's
// autocomplete. Declared before "/:id" so it isn't swallowed by that route.
router.get("/research-areas", async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SELECT DISTINCT research_area FROM theses ORDER BY research_area ASC"
    );
    res.json(rows.map((r) => r.research_area));
  } catch (err) {
    console.error("GET /api/theses/research-areas failed:", err);
    res.status(500).json({ error: "Failed to fetch research areas." });
  }
});

// GET /api/theses/:id
router.get("/:id", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM theses WHERE id = ?", [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: "Record not found." });
    res.json(toApiRecord(rows[0]));
  } catch (err) {
    console.error("GET /api/theses/:id failed:", err);
    res.status(500).json({ error: "Failed to fetch record." });
  }
});

// POST /api/theses
router.post("/", async (req, res) => {
  const problem = validateBody(req.body);
  if (problem) return res.status(400).json({ error: problem });

  const { title, author, researchArea, year, callNumber, abstract, availability } = req.body;
  try {
    const [result] = await pool.query(
      `INSERT INTO theses (title, author, research_area, year, call_number, abstract, availability)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [title.trim(), author.trim(), researchArea.trim(), year, callNumber.trim(), abstract.trim(), availability || "available"]
    );
    const [rows] = await pool.query("SELECT * FROM theses WHERE id = ?", [result.insertId]);
    res.status(201).json(toApiRecord(rows[0]));
  } catch (err) {
    if (err.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ error: "That call number is already in use." });
    }
    console.error("POST /api/theses failed:", err);
    res.status(500).json({ error: "Failed to create record." });
  }
});

// PUT /api/theses/:id
router.put("/:id", async (req, res) => {
  const problem = validateBody(req.body);
  if (problem) return res.status(400).json({ error: problem });

  const { title, author, researchArea, year, callNumber, abstract, availability } = req.body;
  try {
    const [result] = await pool.query(
      `UPDATE theses
       SET title = ?, author = ?, research_area = ?, year = ?, call_number = ?, abstract = ?, availability = ?
       WHERE id = ?`,
      [title.trim(), author.trim(), researchArea.trim(), year, callNumber.trim(), abstract.trim(), availability, req.params.id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: "Record not found." });
    const [rows] = await pool.query("SELECT * FROM theses WHERE id = ?", [req.params.id]);
    res.json(toApiRecord(rows[0]));
  } catch (err) {
    if (err.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ error: "That call number is already in use." });
    }
    console.error("PUT /api/theses/:id failed:", err);
    res.status(500).json({ error: "Failed to update record." });
  }
});

// DELETE /api/theses/:id
router.delete("/:id", async (req, res) => {
  try {
    const [result] = await pool.query("DELETE FROM theses WHERE id = ?", [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: "Record not found." });
    res.status(204).send();
  } catch (err) {
    console.error("DELETE /api/theses/:id failed:", err);
    res.status(500).json({ error: "Failed to delete record." });
  }
});

// Convert a MySQL row (snake_case) to the camelCase shape the frontend
// already expects, so js/repository.js needs minimal changes.
function toApiRecord(row) {
  return {
    id: row.id,
    title: row.title,
    author: row.author,
    researchArea: row.research_area,
    year: row.year,
    callNumber: row.call_number,
    abstract: row.abstract,
    availability: row.availability,
    dateAdded: row.date_added,
  };
}

module.exports = router;
