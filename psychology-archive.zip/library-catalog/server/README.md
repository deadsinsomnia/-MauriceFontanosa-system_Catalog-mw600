# Backend — Express API + XAMPP MySQL

A REST API for the thesis archive, backed by MySQL. This folder is
self-contained: it doesn't touch anything in the frontend yet (that's a
separate, optional step — see the bottom of this file).

## 1. Start MySQL in XAMPP

1. Open the **XAMPP Control Panel**.
2. Click **Start** next to **MySQL**. (You don't need Apache running for
   any of this — Express is its own server.)
3. Click **Admin** next to MySQL to open **phpMyAdmin**, or note that it's
   at `http://localhost/phpmyadmin`.

## 2. Create the database and table

Pick whichever is easier for you:

**Option A — phpMyAdmin (no command line):**
1. In phpMyAdmin, click the **Import** tab.
2. Choose `server/sql/schema.sql`, click **Go**. This creates the
   `psych_archive` database and the `theses` table.
3. Click **Import** again, choose `server/sql/seed.sql`, click **Go**.
   This loads the same 8 sample records the static build uses.

**Option B — command line** (XAMPP's `mysql` binary is usually under
`C:\xampp\mysql\bin\mysql.exe` on Windows, or already on your `PATH` on
macOS/Linux installs):

```bash
mysql -u root -p < sql/schema.sql
mysql -u root -p psych_archive < sql/seed.sql
```

XAMPP's default MySQL root user has **no password** — just press Enter at
the password prompt.

## 3. Configure and install the API

```bash
cd server
cp .env.example .env
npm install
```

Open `.env` — the defaults (`root` user, empty password, port `3306`,
database `psych_archive`) match a stock XAMPP install. Only change it if
you've customized your MySQL setup.

## 4. Run it

```bash
npm start
```

You should see:

```
Psychology Archive API running at http://localhost:4000
Health check: http://localhost:4000/api/health
```

Visit `http://localhost:4000/api/health` in a browser — it should report
`{"status":"ok","database":"connected"}`. If `database` says
`"unreachable"`, double-check MySQL is running in XAMPP and that `.env`
matches your setup.

(`npm run dev` uses `nodemon` instead, which restarts the server
automatically whenever you edit a file — handy while developing.)

## API reference

All endpoints are under `/api/theses` and exchange JSON. Field names are
camelCase (`researchArea`, `callNumber`) to match the frontend, even though
the database columns are snake_case (`research_area`, `call_number`).

| Method | Path                          | Purpose                              |
|--------|-------------------------------|----------------------------------------|
| GET    | `/api/theses`                 | List all records                       |
| GET    | `/api/theses?search=memory`   | Filter by title/author substring       |
| GET    | `/api/theses?area=Clinical+Psychology` | Filter by exact research area |
| GET    | `/api/theses?status=available`| Filter by borrowing status             |
| GET    | `/api/theses/research-areas`  | Distinct list of research areas        |
| GET    | `/api/theses/:id`             | One record                             |
| POST   | `/api/theses`                 | Create a record (JSON body)            |
| PUT    | `/api/theses/:id`             | Update a record (JSON body)            |
| DELETE | `/api/theses/:id`             | Delete a record                        |

A POST/PUT body looks like:

```json
{
  "title": "Example Thesis Title",
  "author": "Jordan Reyes",
  "researchArea": "Clinical Psychology",
  "year": "2024",
  "callNumber": "PSY-2024-100",
  "abstract": "A summary of the research question, method, and findings...",
  "availability": "available"
}
```

Quick manual test with curl:

```bash
curl http://localhost:4000/api/theses
curl -X POST http://localhost:4000/api/theses \
  -H "Content-Type: application/json" \
  -d '{"title":"Test","author":"A. Student","researchArea":"Clinical Psychology","year":"2024","callNumber":"PSY-2024-999","abstract":"A short test abstract."}'
```

## Notes on what was and wasn't tested here

This was written and syntax-checked, and the validation/row-mapping logic
was unit-tested in isolation, but it hasn't been run against a live XAMPP
MySQL instance or had `npm install` actually complete — this sandbox has
no network access to reach either. Standard `mysql2`/`express` patterns
were used throughout, but do run the steps above yourself and watch the
terminal output; if something doesn't match (a different MySQL root
password, a port already in use), the error messages from `npm start` or
the `/api/health` check should point at it directly.

## Connecting the frontend (optional next step)

The frontend currently stores data in the browser's `localStorage` via
`js/repository.js`. To make it use this API instead, that file's five
functions would be rewritten to use `fetch("http://localhost:4000/api/theses")`
instead of `localStorage`, and become `async` — which means every call site
(`catalog.js`, `detail.js`, `add.js`, `edit.js`) needs an `await` added.
That's a deliberate separate step rather than something bundled in here —
ask if you'd like it done.
