-- Sample data — the same 8 records the static build seeds into localStorage.
-- Run after schema.sql:
--   mysql -u root -p psych_archive < sql/seed.sql

USE psych_archive;

INSERT INTO theses (title, author, research_area, year, call_number, abstract, availability) VALUES
('Attachment Styles and Emotion Regulation in Adult Romantic Relationships', 'Priya Anand', 'Clinical Psychology', '2023', 'PSY-2023-014',
 'This study examines how adult attachment orientation predicts the emotion-regulation strategies partners use during conflict. Ninety-four cohabiting couples completed the Experiences in Close Relationships scale and a structured conflict-recall task. Anxious attachment was associated with greater reliance on suppression, while avoidant attachment predicted lower engagement during repair attempts. Findings are discussed in relation to emotionally focused therapy.',
 'available'),

('Working Memory Load and Susceptibility to Misinformation', 'Dr. Corwin Alde', 'Cognitive Psychology', '2021', 'PSY-2021-002',
 'Across three experiments, participants viewed simulated news events followed by misleading post-event information under varying working-memory load. Higher concurrent load increased susceptibility to the misinformation effect on later recognition tests, but only when the misleading detail was central to the narrative. Results support a resource-limited account of source monitoring.',
 'checked-out'),

('Peer Victimization and Self-Concept Development in Early Adolescence', 'Renata Okafor', 'Developmental Psychology', '2022', 'PSY-2022-031',
 'This longitudinal study followed 210 students from grades 6 through 8 to assess how relational and overt peer victimization shape global and domain-specific self-concept. Relational victimization showed the strongest negative association with social self-concept, and this relationship was partially buffered by close friendship quality. Implications for school-based intervention are discussed.',
 'available'),

('In-Group Favoritism Under Minimal Group Conditions: A Replication', 'Hugh Tarrant', 'Social Psychology', '2020', 'PSY-2020-047',
 'A pre-registered replication of the classic minimal group paradigm was conducted with a university sample (N = 168) to test whether arbitrary group assignment alone is sufficient to produce resource-allocation bias. In-group favoritism was observed at a smaller effect size than the original studies, and its magnitude was moderated by participants'' self-reported need for group belonging.',
 'available'),

('Remote Work Autonomy and Burnout Among Early-Career Professionals', 'Lian Osei', 'Industrial-Organizational Psychology', '2023', 'PSY-2023-019',
 'Using a mixed-methods design, this thesis investigates how perceived autonomy in remote work arrangements relates to emotional exhaustion among employees in their first five years of a career. Survey data from 187 respondents indicated that autonomy buffered burnout only when paired with clearly communicated performance expectations, a pattern corroborated in follow-up interviews.',
 'reserved'),

('Therapeutic Alliance as a Predictor of Outcome in Brief CBT for Anxiety', 'Delphine Cruz', 'Counseling Psychology', '2019', 'PSY-2019-008',
 'This thesis analyzes session-by-session alliance ratings from 58 clients receiving an eight-session CBT protocol for generalized anxiety. Early alliance strength, rather than alliance growth over time, was the stronger predictor of symptom reduction at termination, suggesting that establishing rapport in the first sessions may be disproportionately important in brief treatment formats.',
 'available'),

('Sleep Fragmentation and Prospective Memory in Undergraduate Students', 'Yusuf Bramwell', 'Cognitive Psychology', '2022', 'PSY-2022-011',
 'Actigraphy and self-report sleep logs were collected from 76 undergraduates over two weeks alongside a time-based prospective memory task. Greater night-to-night sleep fragmentation, independent of total sleep time, predicted more missed prospective-memory cues, pointing to sleep continuity rather than duration as the more relevant factor for this cognitive domain.',
 'available'),

('Neural Correlates of Cognitive Reappraisal in Adolescents with Anxiety', 'Dr. Marisol Feyn', 'Neuropsychology', '2021', 'PSY-2021-025',
 'Using fMRI during an emotion-regulation task, this study compares prefrontal-amygdala connectivity during cognitive reappraisal in adolescents with an anxiety disorder diagnosis and matched controls. The anxiety group showed reduced ventrolateral prefrontal engagement and weaker top-down connectivity, a pattern that correlated with self-reported reappraisal difficulty in daily life.',
 'checked-out');
