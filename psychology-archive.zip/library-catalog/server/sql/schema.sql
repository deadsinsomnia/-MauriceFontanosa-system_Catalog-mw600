-- Psychology Research Archive — database schema
-- Run this in phpMyAdmin (Import tab) or via the mysql CLI:
--   mysql -u root -p < sql/schema.sql

CREATE DATABASE IF NOT EXISTS psych_archive
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE psych_archive;

CREATE TABLE IF NOT EXISTS theses (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  title          VARCHAR(255)  NOT NULL,
  author         VARCHAR(255)  NOT NULL,
  research_area  VARCHAR(100)  NOT NULL,
  year           CHAR(4)       NOT NULL,
  call_number    VARCHAR(50)   NOT NULL UNIQUE,
  abstract       TEXT          NOT NULL,
  availability   ENUM('available', 'checked-out', 'reserved')
                                NOT NULL DEFAULT 'available',
  date_added     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE INDEX idx_theses_research_area ON theses (research_area);
CREATE INDEX idx_theses_availability ON theses (availability);
